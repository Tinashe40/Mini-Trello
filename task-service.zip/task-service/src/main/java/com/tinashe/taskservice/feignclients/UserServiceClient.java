package com.tinashe.taskservice.feignclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "user-service", url = "${feign.client.config.user-service.url}")
public class UserServiceClient {
  @GetMapping("/api/users/{id}")
  User getUserById(@PathVariable Long id);
}
